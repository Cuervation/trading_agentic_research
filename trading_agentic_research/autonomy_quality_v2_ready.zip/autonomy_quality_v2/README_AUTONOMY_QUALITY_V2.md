# Autonomy Quality v2

Este paquete instala las mejoras que faltaban porque tus `Test-Path` dieron `False`.

## Qué agrega

- `scripts/research/strategy_effect_signature.py`
- `scripts/research/pre_run_duplicate_guard.py`
- `scripts/research/branch_exhaustion.py`
- `scripts/research/spy_feature_diagnostics.py`
- `scripts/research/autonomy_quality_report.py`

## Qué parchea

- `scripts/research_loop.py`
  - agrega guard anti-duplicado antes de `run_backtest`
  - si detecta duplicado, crea un run bloqueado con `audit.json`, consume la hipótesis y retorna OK para que el batch pueda seguir
  - registra strategy-effect signature al finalizar una corrida real

- `scripts/run_research_batch.py`
  - actualiza branch exhaustion después de cada audit
  - escribe `reports/autonomy_quality_report.md`

- `scripts/research/feature_space_expansion_factory.py`
  - saltea ramas agotadas

- `backtester/signal_builder.py`
  - corrige el market filter de SPY: si `spy_close_vs_sma50_pct` es NaN, intenta usar `close_vs_sma50_pct` de la fila SPY
  - si el filtro es estricto y no hay métrica, bloquea el rebalance en vez de permitir fallback silencioso

- `backtester/execution.py`
  - captura `warnings.warn()` de signal_builder y los guarda en `diagnostics.warnings`

- `backtester/validation.py`
  - considera `data_quality_critical` como warning crítico

## Cómo aplicar

Desde el repo:

```powershell
cd "C:\Pythons\ML-Trading\Momentum\trading_agentic_research"

.\autonomy_quality_v2\tools\apply_autonomy_quality_v2.ps1 -RepoRoot "."
.\autonomy_quality_v2\tools\verify_autonomy_quality_v2.ps1 -RepoRoot "."
```

## Qué debería cambiar

Antes:

```text
Research loop plan for EXP_118: 3 commands
Run completed: EXP_118
Global duplicate: EXP_060
```

Después, si la estrategia ya existe:

```text
Pre-run duplicate guard blocked EXP_129: duplicate_strategy_effect_signature duplicate_of=EXP_060
```

Eso significa que no gastó el backtest.

## Seguridad

No toca `state/` destructivamente. Solo agrega índices/reportes:
- `state/strategy_effect_index.json`
- `state/branch_exhaustion.json`
- `state/pre_run_duplicate_blocks.jsonl`

No mueve `AUTO_002`, no promueve baseline, no borra runs, no revive EXP_052 ni EXP_054.
