param(
  [Parameter(Mandatory=$true)]
  [string]$RepoRoot
)

$ErrorActionPreference = "Stop"
$PatchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$FilesRoot = Join-Path $PatchRoot "files"

if (!(Test-Path $RepoRoot)) { throw "RepoRoot no existe: $RepoRoot" }
Set-Location $RepoRoot

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$backup = Join-Path $RepoRoot "_backup_feature_space_cooldown_aware_$ts"
New-Item -ItemType Directory -Force -Path $backup | Out-Null

$targets = @(
  "scripts/research/feature_space_expansion_factory.py",
  "tests/test_feature_space_cooldown_aware.py"
)

foreach ($rel in $targets) {
  $src = Join-Path $FilesRoot $rel
  $dst = Join-Path $RepoRoot $rel
  if (!(Test-Path $src)) { throw "Falta archivo en patch: $src" }
  if (Test-Path $dst) {
    $bak = Join-Path $backup $rel
    New-Item -ItemType Directory -Force -Path (Split-Path $bak -Parent) | Out-Null
    Copy-Item $dst $bak -Force
  }
  New-Item -ItemType Directory -Force -Path (Split-Path $dst -Parent) | Out-Null
  Copy-Item $src $dst -Force
  Write-Host "OK -> $rel"
}

Write-Host "`n=== py_compile ==="
python -m py_compile .\scripts\research\feature_space_expansion_factory.py

Write-Host "`n=== pytest focal ==="
python -m pytest .\tests\test_feature_space_cooldown_aware.py -q

Write-Host "`n=== git status ==="
git status --short

Write-Host "`nBackup: $backup"
