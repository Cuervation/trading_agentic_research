# Feature Space Cooldown-Aware Patch

Este cambio hace que `scripts/research/feature_space_expansion_factory.py` no genere hipótesis en familias que el selector ya rechaza por `subspace_cooldowns.json`.

## Por qué

El último run mostró:

- recovery generation generó 5 hipótesis nuevas
- `generation_selection_feedback` diagnosticó `selectable=0`
- motivo: `selector_memory_rejected: 5`

La causa era que el generador seguía creando familias en cooldown, por ejemplo:

- `feature_space_composite_confirmation`
- `feature_space_regime`

## Qué hace

- Lee `state/subspace_cooldowns.json`.
- Trata cooldowns sin `cooldown_until` como activos, igual que el selector.
- Antes de agregar una hipótesis, calcula la familia efectiva.
- Si la familia está en cooldown, la saltea con `reason=family_cooldown`.
- Sigue con la próxima capa, por ejemplo `rank_topn` o `rank_exit`.

## Aplicación

```powershell
Expand-Archive .\feature_space_cooldown_aware_files.zip -DestinationPath .\feature_space_cooldown_aware_files -Force

.\feature_space_cooldown_aware_files\feature_space_cooldown_aware_files\apply_feature_space_cooldown_aware.ps1 `
  -RepoRoot "C:\Pythons\ML-Trading\Momentum\trading_agentic_research"
```

## Prueba recomendada

```powershell
python .\scripts\run_research_batch_autonomous.py `
  --max-runs 25 `
  --project-config ".\configs\project_config.json" `
  --state-dir ".\state" `
  --runs-dir ".\runs" `
  --reports-dir ".\reports"
```

Esperado: si `feature_space_composite_confirmation` y `feature_space_regime` están en cooldown, el generador debería pasar a capas `rank_topn` / `rank_exit` en vez de generar más `CONF` / `MKT` que luego el selector rechaza.
