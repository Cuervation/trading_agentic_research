# Autonomy Quality v5

v5 no depende de anchors largos. Inserta el guard justo antes de `build_commands(...)`, maneja `return 3` en el batch, y reemplaza el market filter SPY con fallback métrico ordenado.

```powershell
cd "C:\Pythons\ML-Trading\Momentum\trading_agentic_research"
Expand-Archive "$env:USERPROFILE\Downloads\autonomy_quality_v5_ready.zip" -DestinationPath "." -Force
.\autonomy_quality_v5\tools\apply_autonomy_quality_v5.ps1 -RepoRoot "."
.\autonomy_quality_v5\tools\verify_autonomy_quality_v5.ps1 -RepoRoot "."
```

Verificación manual:

```powershell
Select-String -Path .\scripts\research_loop.py -Pattern "check_pre_run_duplicate_guard|return 3"
Select-String -Path .\scripts\run_research_batch.py -Pattern "code == 3|pre-run guard blocked"
Select-String -Path .\backtester\signal_builder.py -Pattern "metric_candidates|critical: SPY market filter"
```
