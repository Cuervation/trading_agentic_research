# Manual install - continuous learning fix

Copiá el contenido de este ZIP encima de la raíz del repo.

La estructura esperada del repo es:

```text
trading_agentic_research/
  scripts/
  backtester/
  state/
  runs/
```

Si al descomprimir te queda una carpeta `trading_agentic_research/` encima de otra, copiá los archivos internos respetando las rutas.

## Archivos nuevos

- `trading_agentic_research/scripts/research/artifact_index.py`
- `trading_agentic_research/scripts/research/research_ledger.py`
- `trading_agentic_research/scripts/research/champion_governance.py`
- `trading_agentic_research/scripts/research/rebuild_research_state_from_runs.py`
- `trading_agentic_research/scripts/research/audit_learning_progress.py`
- `trading_agentic_research/tests/test_continuous_learning_governance.py`

## Archivo reemplazado

- `trading_agentic_research/scripts/evaluate_candidate.py`

Este reemplazo mantiene lo anterior y agrega:

- detección global de duplicados por firma de artifacts;
- actualización de `state/artifact_hash_index.json`;
- actualización de `state/research_ledger.jsonl`;
- actualización de `state/champion_runs.json`;
- clasificación explícita del valor entregado por corrida.

## Comandos sugeridos

Desde la carpeta del proyecto donde existen `scripts/`, `runs/`, `state/`:

```powershell
python -m py_compile .\scripts\evaluate_candidate.py
python -m py_compile .\scripts\research\artifact_index.py
python -m py_compile .\scripts\research\research_ledger.py
python -m py_compile .\scripts\research\champion_governance.py
python -m py_compile .\scripts\research\rebuild_research_state_from_runs.py
python -m py_compile .\scripts\research\audit_learning_progress.py
```

Después reconstruí estado desde las corridas existentes:

```powershell
python .\scripts\research\rebuild_research_state_from_runs.py --runs-dir .\runs --state-dir .\state --reports-dir .\reports
```

Para ver si el sistema está aprendiendo:

```powershell
python .\scripts\research\audit_learning_progress.py --runs-dir .\runs --state-dir .\state --reports-dir .\reports
```

Opcional, correr tests:

```powershell
python -m pytest .\tests\test_continuous_learning_governance.py
```

## Qué genera

- `state/artifact_hash_index.json`: índice global de firmas `metrics + trades + equity`.
- `state/duplicate_runs.json`: duplicados históricos.
- `state/research_ledger.jsonl`: ledger de aprendizaje por corrida.
- `state/champion_runs.json`: best champion, promotion candidates, secondary candidates.
- `reports/rebuilt_research_state.md`: reporte de reconstrucción.
- `reports/learning_progress.md`: auditoría de progreso.

## Importante

Por default, `rebuild_research_state_from_runs.py` NO pisa los `audit.json` dentro de cada run. Si querés regenerarlos también:

```powershell
python .\scripts\research\rebuild_research_state_from_runs.py --runs-dir .\runs --state-dir .\state --reports-dir .\reports --write-audits
```

Yo arrancaría sin `--write-audits` para auditar sin tocar histórico, y luego lo correría con `--write-audits` si el reporte te convence.

## Próximo paso luego de instalar

Seguí corriendo con el batch real, no con el modo mock de `scripts/research/autonomous.py`.

El objetivo ahora es que cada corrida termine clasificada en `research_ledger.jsonl` con uno de estos valores:

- `new_champion`
- `promotion_candidate`
- `secondary_candidate`
- `defensive_secondary_candidate`
- `aggressive_champion`
- `rejected_with_learning`
- `duplicate_blocked`
- `metric_no_effect_blocked`
- `missing_artifacts`
