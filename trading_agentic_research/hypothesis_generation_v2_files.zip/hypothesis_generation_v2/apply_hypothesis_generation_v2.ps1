param(
  [Parameter(Mandatory=$true)]
  [string]$RepoRoot
)

$ErrorActionPreference = "Stop"
$patchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$filesRoot = Join-Path $patchRoot "files"
$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$backupRoot = Join-Path $RepoRoot "_backup_hypothesis_generation_v2_$ts"

if (!(Test-Path $RepoRoot)) { throw "RepoRoot no existe: $RepoRoot" }
if (!(Test-Path $filesRoot)) { throw "No encuentro carpeta files en: $filesRoot" }

Set-Location $RepoRoot
Write-Host "`n=== Git status antes ==="
git status --short

New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null

Write-Host "`n=== Copiando archivos modificados ==="
Get-ChildItem $filesRoot -Recurse -File | ForEach-Object {
  $rel = $_.FullName.Substring($filesRoot.Length).TrimStart("\", "/")
  $target = Join-Path $RepoRoot $rel
  $targetDir = Split-Path $target -Parent
  if (!(Test-Path $targetDir)) { New-Item -ItemType Directory -Force -Path $targetDir | Out-Null }

  if (Test-Path $target) {
    $backupTarget = Join-Path $backupRoot $rel
    $backupDir = Split-Path $backupTarget -Parent
    if (!(Test-Path $backupDir)) { New-Item -ItemType Directory -Force -Path $backupDir | Out-Null }
    Copy-Item $target $backupTarget -Force
  }

  Copy-Item $_.FullName $target -Force
  Write-Host "OK -> $rel"
}

Write-Host "`n=== Git status despues ==="
git status --short

Write-Host "`n=== Validando py_compile ==="
python -m py_compile .\backtester\signal_builder.py
python -m py_compile .\scripts\research\feature_space_expansion_factory.py

Write-Host "`n=== Validando tests ==="
python -m pytest .\tests\test_feature_space_expansion_v2.py -q
python -m pytest .\tests\test_final_autonomy_closure.py .\tests\test_autonomy_final_scope.py -q

Write-Host "`n=== Smoke test de generación feature-space v2 ==="
python .\scripts\research\feature_space_expansion_factory.py `
  --parent-strategy-config .\configs\generated\HYP_AUTO_TIME_SERIES_MOMENTUM_SEED.json `
  --hypothesis-bank .\bibliography\hypothesis_bank.jsonl `
  --state-dir .\state `
  --max-new 3 `
  --reason smoke_hypothesis_generation_v2

Write-Host "`nPatch aplicado. Backup en: $backupRoot"
