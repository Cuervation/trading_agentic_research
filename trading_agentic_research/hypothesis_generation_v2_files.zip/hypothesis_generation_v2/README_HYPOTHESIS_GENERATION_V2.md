# Hypothesis Generation v2

Este paquete toca solo la capa de generación/ejecución real de señales:

- `scripts/research/feature_space_expansion_factory.py`
- `backtester/signal_builder.py`
- `tests/test_feature_space_expansion_v2.py`

## Objetivo

Cuando el feature-space simple se agota (`no_new_feature_space_hypotheses` porque todos los rankings simples ya existen), el sistema ahora puede generar hipótesis compuestas, pero no random:

- ranking + confirmación real por `risk_filters.conditions`
- ranking + variantes reales de `market_filter`
- ranking + `top_n`
- ranking + `exit_rule.rank_threshold`

## Cambio importante en backtester

`signal_builder.py` ahora hace efectivos knobs que antes eran casi decorativos:

- respeta `ranking.order = asc|desc`
- aplica `risk_filters.require_non_null_fields`
- aplica `risk_filters.conditions`

Esto evita generar hipótesis que solo cambian JSON pero no cambian la lógica real del backtest.

## Aplicación

```powershell
Expand-Archive .\hypothesis_generation_v2_files.zip -DestinationPath .\hypothesis_generation_v2_files -Force

.\hypothesis_generation_v2_files\apply_hypothesis_generation_v2.ps1 `
  -RepoRoot "C:\Pythons\ML-Trading\Momentum\trading_agentic_research"
```

Después corré una tanda chica:

```powershell
python .\scripts\run_research_batch_autonomous.py `
  --max-runs 5 `
  --project-config ".\configs\project_config.json" `
  --state-dir ".\state" `
  --runs-dir ".\runs" `
  --reports-dir ".\reports"
```

## Qué esperamos

Si el feature-space simple estaba agotado, deberías ver nuevas hipótesis con ids parecidos a:

- `HYP_FSPACE_AUTO_002_RANK_RET_26W_PCT_CONF_SMA20_POS_V1`
- `HYP_FSPACE_AUTO_002_RANK_CHANNEL_SLOPE_PCT_MKT_STRICT_SPY_V1`
- `HYP_FSPACE_AUTO_002_RANK_CHANNEL_R2_TOPN_7_V1`

Y ya no solamente variantes `RANK_<feature>` simples.
