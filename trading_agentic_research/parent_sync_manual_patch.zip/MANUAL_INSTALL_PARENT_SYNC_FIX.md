# Manual patch - Parent/champion/config sync

Este patch corrige el punto que quedó flojo después del rebuild:

- `champion_runs.json` podía quedar con `current_parent_run_id = EXP_001` aunque `current_parent.json` diga `AUTO_002`.
- `run_research_batch.py` podía generar nuevas configs desde `configs/baseline_momentum_trend_v1.json` aunque el champion real sea `AUTO_002`.
- Ahora se agrega `scripts/research/parent_state.py` para sincronizar parent/champion y resolver el config real del parent.

## Archivos incluidos

Copiar en el repo respetando rutas:

```text
trading_agentic_research/scripts/research/parent_state.py
trading_agentic_research/scripts/research/sync_parent_state.py
trading_agentic_research/scripts/research/rebuild_research_state_from_runs.py
trading_agentic_research/scripts/run_research_batch.py
trading_agentic_research/tests/test_parent_state_sync.py
```

## Validación rápida

Desde `trading_agentic_research`:

```powershell
python -m py_compile .\scripts\research\parent_state.py
python -m py_compile .\scripts\research\sync_parent_state.py
python -m py_compile .\scripts\research\rebuild_research_state_from_runs.py
python -m py_compile .\scripts\run_research_batch.py
python -m pytest .\tests\test_parent_state_sync.py
```

## Reconstruir y sincronizar estado

```powershell
python .\scripts\research\rebuild_research_state_from_runs.py `
  --runs-dir .\runs `
  --state-dir .\state `
  --reports-dir .\reports `
  --strategy-registry .\configs\strategy_registry.json `
  --generated-configs-dir .\configs\generated
```

Después:

```powershell
python .\scripts\research\sync_parent_state.py `
  --state-dir .\state `
  --strategy-registry .\configs\strategy_registry.json `
  --generated-configs-dir .\configs\generated
```

Esperado:

```json
{
  "current_parent_run_id": "AUTO_002",
  "current_parent_strategy_id": "HYP_AUTO_TIME_SERIES_MOMENTUM_SEED",
  "current_parent_hypothesis_id": "HYP_AUTO_TIME_SERIES_MOMENTUM_SEED",
  "current_parent_config_path": "configs/generated/HYP_AUTO_TIME_SERIES_MOMENTUM_SEED.json"
}
```

Si `current_parent_config_path` queda `null`, significa que falta registrar o subir la config JSON exacta de `AUTO_002`. En ese caso, no conviene correr otro lote todavía.

## Lote chico recomendado

Solo si `current_parent_config_path` existe:

```powershell
python .\scripts\run_research_batch.py `
  --max-runs 5 `
  --weekly-file ".\TU_WEEKLY.csv" `
  --daily-folder ".\TU_DAILY_FOLDER" `
  --project-config ".\configs\project_config.json" `
  --state-dir ".\state" `
  --runs-dir ".\runs" `
  --reports-dir ".\reports" `
  --prefer-unseen `
  --auto-generate-missing-configs `
  --auto-generate-hypotheses-on-block `
  --max-repeats-per-hypothesis 1
```

El batch imprimirá:

```text
Using parent strategy config: ...
```

Debe mostrar el config del champion (`AUTO_002`), no el baseline viejo.
