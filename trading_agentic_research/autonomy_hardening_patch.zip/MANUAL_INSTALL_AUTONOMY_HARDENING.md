# Manual install - autonomy hardening patch

Copiar los archivos del ZIP sobre la raíz del repo.

## Qué corrige

1. `run_research_batch_autonomous.py` ahora escribe `state/autonomy_blocker.json` y devuelve exit codes útiles:
   - `0`: corrió o terminó según batch
   - `2`: data preflight failed
   - `4`: parent config faltante
2. `data_path_resolver.py` soporta:
   - CLI paths
   - env vars `TRADING_WEEKLY_FILE` y `TRADING_DAILY_FOLDER`
   - `configs/local_data_paths.json`
   - `configs/project_config.json`
   - autodetección
3. `autonomous_hypothesis_factory.py` ahora:
   - deduplica cambios reales ignorando `strategy_id`
   - mira `research_ledger.jsonl` para saltear ejes agotados por duplicados/no-effect
   - genera más familias de refinamiento alrededor del champion
4. `research_loop.py` pasa `--runs-dir` al backtester, evitando escribir en `runs/` cuando se pide otro directorio.
5. `sync_strategy_registry.py` registra el current parent en `strategy_registry.json` de forma idempotente.

## Recomendado: paths locales

Crear `configs/local_data_paths.json` a partir de `configs/local_data_paths.example.json` y NO subirlo si tiene rutas absolutas privadas.

Alternativa:

```powershell
$env:TRADING_WEEKLY_FILE="C:\ruta\weekly.csv"
$env:TRADING_DAILY_FOLDER="C:\ruta\daily_folder"
```

## Validar

```powershell
python -m py_compile .\scripts\research\autonomy_blocker.py
python -m py_compile .\scripts\research\data_path_resolver.py
python -m py_compile .\scripts\research\autonomous_hypothesis_factory.py
python -m py_compile .\scripts\research\sync_strategy_registry.py
python -m py_compile .\scripts\run_research_batch_autonomous.py
python -m py_compile .\scripts\research_loop.py
python -m pytest .\tests\test_autonomy_blocker_and_paths.py .\tests\test_autonomous_hypothesis_factory_hardening.py .\tests\test_research_loop_runs_dir.py
```

## Correr lote chico

```powershell
python .\scripts\run_research_batch_autonomous.py `
  --max-runs 5 `
  --project-config ".\configs\project_config.json" `
  --state-dir ".\state" `
  --runs-dir ".\runs" `
  --reports-dir ".\reports"
```

Después:

```powershell
python .\scripts\research\audit_learning_progress.py --runs-dir .\runs --state-dir .\state --reports-dir .\reports
```
