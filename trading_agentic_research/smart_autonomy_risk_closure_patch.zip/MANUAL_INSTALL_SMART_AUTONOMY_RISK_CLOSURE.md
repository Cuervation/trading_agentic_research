# Smart Autonomy Risk Closure Patch

This patch closes the last fine-grained autonomy risks:

1. `run_research_batch_autonomous.py`
   - If value-hypothesis fallback and literature miner still cannot create eligible hypotheses,
     the wrapper now runs `paper_searcher.py` internally through `generate_paper_ideas(...)`,
     then re-runs the literature miner.
   - This closes the gap: `paper_searcher -> paper_ideas.jsonl -> literature miner -> hypothesis_bank`.

2. `literature_hypothesis_miner.py`
   - Deduplicates `state/missing_feature_tasks.jsonl` by parent/source/candidate/missing-features.

3. `feature_engineering_agent.py`
   - Generated candidate script reads CSV with `sep=None, engine="python"` to support `;` and `,`.
   - Generated test checks semicolon parsing.

4. `autonomy_readiness.py`
   - Resolves all repo-relative paths from `--repo-root` to avoid false negatives when run outside repo root.

## Install

Copy files into the repo root preserving paths.

## Validate

```powershell
python -m py_compile .\scripts\run_research_batch_autonomous.py
python -m py_compile .\scripts\research\literature_hypothesis_miner.py
python -m py_compile .\scripts\research\feature_engineering_agent.py
python -m py_compile .\scripts\research\autonomy_readiness.py

python -m pytest `
  .\tests\test_autonomous_wrapper_paper_searcher_fallback.py `
  .\tests\test_literature_miner_missing_task_dedupe.py `
  .\tests\test_feature_engineering_semicolon_candidate.py `
  .\tests\test_autonomy_readiness_repo_root.py
```
