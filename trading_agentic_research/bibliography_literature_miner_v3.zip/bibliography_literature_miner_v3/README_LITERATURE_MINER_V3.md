# Literature miner v3

Replaces `scripts/research/literature_hypothesis_miner.py`.

Adds:
- direct execution fix (`sys.path` root)
- multiple causal variants per paper idea
- ranking + confirmation conditions
- regime strict/relaxed/ablation variants
- missing feature task suggestions
- detailed counters for existing ids and duplicate signatures

Apply:
```powershell
.\bibliography_literature_miner_v3\apply_literature_miner_v3.ps1 -RepoRoot "C:\Pythons\ML-Trading\Momentum\trading_agentic_research"
```
