param(
  [Parameter(Mandatory=$true)]
  [string]$RepoRoot
)

$ErrorActionPreference = "Stop"

$src = Join-Path $PSScriptRoot "scripts\research\literature_hypothesis_miner.py"
$dst = Join-Path $RepoRoot "scripts\research\literature_hypothesis_miner.py"

if (!(Test-Path $src)) { throw "Source file not found: $src" }
if (!(Test-Path (Split-Path $dst -Parent))) { throw "Repo path not found: $(Split-Path $dst -Parent)" }

$backup = "$dst.bak_$(Get-Date -Format yyyyMMdd_HHmmss)"
Copy-Item $dst $backup -Force
Copy-Item $src $dst -Force

Push-Location $RepoRoot
try {
  python -m py_compile .\scripts\research\literature_hypothesis_miner.py
  Write-Host "OK: literature_hypothesis_miner.py replaced and compiled."
  Write-Host "Backup: $backup"
} finally {
  Pop-Location
}
